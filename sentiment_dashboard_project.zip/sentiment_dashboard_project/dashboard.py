"""Live sentiment dashboard.  Run:  streamlit run dashboard.py
Terminal 1: python src/stream_simulator.py      Terminal 2: streamlit run dashboard.py"""
from pathlib import Path
import pandas as pd
import streamlit as st

LIVE = Path("data/stream/live_tweets.csv")
COLORS = {"positive": "#2ecc71", "neutral": "#f1c40f", "negative": "#e74c3c"}

st.set_page_config(page_title="Live Sentiment Dashboard", page_icon="✈️", layout="wide")
st.title("✈️ Real-Time Public Sentiment Dashboard")
st.caption("Tweets stream in → NLTK cleaning → ML classifier + VADER score → this dashboard (auto-refreshes).")

brand = st.sidebar.selectbox("Brand", ["All"] + ["American", "Delta", "Southwest", "United", "US Airways", "Virgin America"])
window = st.sidebar.selectbox("Trend window", ["5min", "15min", "1h"], index=0)
refresh = st.sidebar.slider("Refresh every (sec)", 2, 30, 5)


@st.fragment(run_every=refresh)
def live_view():
    if not LIVE.exists():
        st.info("Waiting for data… start `python src/stream_simulator.py` in another terminal.")
        return
    df = pd.read_csv(LIVE, parse_dates=["ingested_at"])
    if brand != "All":
        df = df[df["airline"] == brand]
    if df.empty:
        st.warning("No tweets yet for this brand.")
        return

    n = len(df)
    pos, neu, neg = (int((df["sentiment"] == s).sum()) for s in ("positive", "neutral", "negative"))
    net = (pos - neg) / n
    c = st.columns(5)
    c[0].metric("Tweets received", f"{n:,}")
    c[1].metric("Positive 😊", f"{pos/n:.0%}")
    c[2].metric("Neutral 😐", f"{neu/n:.0%}")
    c[3].metric("Negative 😠", f"{neg/n:.0%}")
    c[4].metric("Net sentiment", f"{net:+.2f}", help="(positive − negative) / total. Range −1 to +1.")
    st.divider()

    left, right = st.columns(2)
    with left:
        st.subheader("Sentiment over time")
        t = (df.set_index("ingested_at").groupby([pd.Grouper(freq=window), "sentiment"])
               .size().unstack(fill_value=0).reindex(columns=list(COLORS), fill_value=0))
        st.area_chart(t, color=list(COLORS.values()))
    with right:
        st.subheader("Sentiment by brand")
        st.bar_chart(pd.crosstab(df["airline"], df["sentiment"]).reindex(columns=list(COLORS), fill_value=0),
                     color=list(COLORS.values()))

    st.subheader("Latest tweets")
    st.dataframe(df.sort_values("ingested_at", ascending=False)
                   [["ingested_at", "airline", "sentiment", "vader_compound", "text"]].head(15),
                 width="stretch", hide_index=True)

    st.subheader("📅 Daily sentiment log")
    log = Path("logs/daily_sentiment.csv")
    if log.exists():
        st.dataframe(pd.read_csv(log), width="stretch", hide_index=True)
    else:
        st.caption("Run `python src/daily_log.py` to generate logs/daily_sentiment.csv")


live_view()
