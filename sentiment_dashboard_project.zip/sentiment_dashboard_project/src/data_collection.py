import pandas as pd
from pathlib import Path
from datetime import datetime


RAW_DIR = Path("data/raw")
RAW_DIR.mkdir(parents=True, exist_ok=True)


def collect_from_csv(input_file):
    """
    Load an existing tweet/social-media dataset.
    Expected minimum column: text
    """

    df = pd.read_csv(input_file)

    if "text" not in df.columns:
        raise ValueError("Dataset must contain a 'text' column.")

    # Add timestamp if dataset doesn't have one
    if "created_at" not in df.columns:
        df["created_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    return df


def save_raw_data(df):
    """
    Save collected data into data/raw/
    """

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = RAW_DIR / f"tweets_{timestamp}.csv"

    df.to_csv(output_file, index=False)

    print(f"Raw data saved to: {output_file}")

    return output_file


if __name__ == "__main__":

    input_file = "data/sample_tweets.csv"

    df = collect_from_csv(input_file)

    save_raw_data(df)

    print(f"Collected {len(df)} records.")
