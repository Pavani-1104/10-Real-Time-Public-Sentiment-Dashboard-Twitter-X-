import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

INPUT_FILE = Path("./data/processed/cleaned_tweets.csv")
OUTPUT_DIR = Path("./outputs")

OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def main():
    df = pd.read_csv(INPUT_FILE)

    print("\nSentiment counts:")
    print(df["airline_sentiment"].value_counts())

    print("\nSentiment percentages:")
    print(
        (df["airline_sentiment"].value_counts(normalize=True) * 100)
        .round(2)
    )

    # Overall sentiment
    plt.figure(figsize=(8, 5))

    sns.countplot(
        data=df,
        x="airline_sentiment",
        hue="airline_sentiment",
        palette="Set2",
        legend=False
    )

    plt.title("Overall Tweet Sentiment")
    plt.xlabel("Sentiment")
    plt.ylabel("Number of Tweets")
    plt.tight_layout()

    plt.savefig(OUTPUT_DIR / "sentiment_distribution.png")
    plt.close()

    # Sentiment by airline
    airline_sentiment = pd.crosstab(
        df["airline"],
        df["airline_sentiment"]
    )

    airline_sentiment.plot(
        kind="bar",
        figsize=(12, 6)
    )

    plt.title("Sentiment by Airline")
    plt.xlabel("Airline")
    plt.ylabel("Number of Tweets")
    plt.xticks(rotation=45)
    plt.tight_layout()

    plt.savefig(OUTPUT_DIR / "sentiment_by_airline.png")
    plt.close()

    print("\nAnalysis completed.")
    print("Charts saved in:", OUTPUT_DIR)


if __name__ == "__main__":
    main()
