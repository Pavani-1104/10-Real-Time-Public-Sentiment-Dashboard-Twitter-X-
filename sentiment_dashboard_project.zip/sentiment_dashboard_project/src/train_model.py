"""Train TF-IDF + Logistic Regression on the labelled tweets and save it.
(Replaces the old pipeline.py: same idea, but uses the shared NLTK cleaning and saves the model.)"""
from pathlib import Path
import joblib, pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from nlp import clean_text

df = pd.read_csv("data/raw/Tweets.csv").dropna(subset=["text", "airline_sentiment"])
df["clean"] = df["text"].apply(clean_text)
Xtr, Xte, ytr, yte = train_test_split(df["clean"], df["airline_sentiment"],
                                      test_size=0.2, random_state=42, stratify=df["airline_sentiment"])
model = make_pipeline(TfidfVectorizer(max_features=10000, ngram_range=(1, 2), min_df=2),
                      LogisticRegression(max_iter=1000, class_weight="balanced"))
model.fit(Xtr, ytr)
pred = model.predict(Xte)
print("Accuracy:", round(accuracy_score(yte, pred), 4))
print(classification_report(yte, pred))
Path("models").mkdir(exist_ok=True)
joblib.dump(model, "models/sentiment_model.joblib")
