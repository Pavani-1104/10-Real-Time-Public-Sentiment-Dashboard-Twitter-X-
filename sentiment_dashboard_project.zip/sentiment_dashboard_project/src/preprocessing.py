import pandas as pd
import re
from pathlib import Path

INPUT_FILE = Path("./data/raw/Tweets.csv")
OUTPUT_FILE = Path("./data/processed/cleaned_tweets.csv")


def clean_text(text):
    if pd.isna(text):
        return ""

    text = str(text).lower()
    text = re.sub(r"http\S+|www\S+", "", text)
    text = re.sub(r"@\w+", "", text)
    text = re.sub(r"#", "", text)
    text = re.sub(r"[^a-z\s]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()

    return text


def main():
    print("Loading dataset...")

    df = pd.read_csv(INPUT_FILE)

    print(f"Original rows: {len(df)}")

    df = df.dropna(subset=["text", "airline_sentiment"])

    df["clean_text"] = df["text"].apply(clean_text)

    df = df[df["clean_text"].str.len() > 0]

    OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)

    df.to_csv(OUTPUT_FILE, index=False)

    print(f"Cleaned rows: {len(df)}")
    print(f"Saved to: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
