"""REAL Twitter/X streaming with Tweepy (needs a paid API tier + bearer token).
Same output file/columns as stream_simulator.py, so the dashboard works with either.

    export X_BEARER_TOKEN=...   &&   python src/twitter_stream.py "united airlines"
"""
import os, sys, joblib
from datetime import datetime
import tweepy
from nlp import clean_text, score_sentiment
from stream_simulator import append


MODEL = joblib.load("models/sentiment_model.joblib")


class Listener(tweepy.StreamingClient):
    def on_tweet(self, tweet):
        c, vlabel = score_sentiment(tweet.text)
        clean = clean_text(tweet.text)
        append([[datetime.now().strftime("%Y-%m-%d %H:%M:%S"), tweet.id, BRAND,
                 tweet.text, clean, MODEL.predict([clean])[0], c, vlabel, ""]])


if __name__ == "__main__":
    BRAND = sys.argv[1]
    stream = Listener(os.environ["X_BEARER_TOKEN"])
    for rule in stream.get_rules().data or []:
        stream.delete_rules(rule.id)
    stream.add_rules(tweepy.StreamRule(f'"{BRAND}" lang:en -is:retweet'))
    stream.filter()
