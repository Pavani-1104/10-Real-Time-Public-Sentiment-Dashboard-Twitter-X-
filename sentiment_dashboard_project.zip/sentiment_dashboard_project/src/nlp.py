"""NLTK helpers shared by every script: cleaning + VADER sentiment scoring."""
import re
import nltk

for _pkg in ("vader_lexicon", "stopwords", "wordnet"):
    nltk.download(_pkg, quiet=True)

from nltk.corpus import stopwords
from nltk.sentiment import SentimentIntensityAnalyzer
from nltk.stem import WordNetLemmatizer

_sia = SentimentIntensityAnalyzer()
_lemma = WordNetLemmatizer()
# Keep negations: "not happy" must not become "happy"
_STOP = set(stopwords.words("english")) - {"no", "not", "nor", "never", "n't"}


def clean_text(text) -> str:
    """Lowercase, strip URLs/@mentions/#, keep letters, drop stopwords, lemmatize."""
    if not isinstance(text, str):
        return ""
    t = text.lower()
    t = re.sub(r"http\S+|www\S+|@\w+", "", t)
    t = re.sub(r"[^a-z\s]", " ", t.replace("#", ""))
    return " ".join(_lemma.lemmatize(w) for w in t.split() if w not in _STOP)


def score_sentiment(text):
    """VADER on the RAW text (it uses caps, '!' and emoji as signals).
    Returns (compound in [-1, 1], label)."""
    c = _sia.polarity_scores(str(text))["compound"]
    label = "positive" if c >= 0.05 else "negative" if c <= -0.05 else "neutral"
    return c, label
