"""Simulated real-time stream.
The X/Twitter API free tier no longer allows streaming, so we REPLAY the
14,640-tweet US Airline dataset as if tweets were arriving live.
Each tweet is stamped with the current time, classified by the trained model + scored with NLTK VADER and
appended to data/stream/live_tweets.csv (the dashboard reads this file).

Run:  python src/stream_simulator.py --interval 2 --batch 5
"""
import argparse, time
from datetime import datetime
from pathlib import Path
import joblib
import pandas as pd
from nlp import clean_text, score_sentiment

SRC = Path("data/raw/Tweets.csv")
OUT = Path("data/stream/live_tweets.csv")
MODEL = joblib.load("models/sentiment_model.joblib")  # run src/train_model.py first
COLS = ["ingested_at", "tweet_id", "airline", "text", "clean_text",
        "sentiment", "vader_compound", "vader_label", "human_label"]


def append(rows):
    OUT.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows, columns=COLS).to_csv(
        OUT, mode="a", header=not OUT.exists(), index=False)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--interval", type=float, default=2.0, help="seconds between batches")
    ap.add_argument("--batch", type=int, default=5, help="tweets per batch")
    ap.add_argument("--max", type=int, default=0, help="stop after N tweets (0 = forever)")
    a = ap.parse_args()

    df = pd.read_csv(SRC).sample(frac=1, random_state=42).reset_index(drop=True)
    sent = 0
    for start in range(0, len(df), a.batch):
        rows = []
        for _, r in df.iloc[start:start + a.batch].iterrows():
            comp, vlabel = score_sentiment(r["text"])
            clean = clean_text(r["text"])
            rows.append([datetime.now().strftime("%Y-%m-%d %H:%M:%S"), r["tweet_id"],
                         r["airline"], r["text"], clean, MODEL.predict([clean])[0],
                         comp, vlabel, r["airline_sentiment"]])
        append(rows)
        sent += len(rows)
        print(f"[{datetime.now():%H:%M:%S}] +{len(rows)} tweets (total {sent})")
        if a.max and sent >= a.max:
            break
        time.sleep(a.interval)


if __name__ == "__main__":
    main()
