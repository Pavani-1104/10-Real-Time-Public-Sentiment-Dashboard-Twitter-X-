"""How good is VADER vs the human labels? (Great interview talking point.)"""
import pandas as pd
from sklearn.metrics import classification_report, accuracy_score
from nlp import score_sentiment

df = pd.read_csv("data/raw/Tweets.csv")
pred = df["text"].apply(lambda t: score_sentiment(t)[1])
print("VADER accuracy:", round(accuracy_score(df.airline_sentiment, pred), 4))
print(classification_report(df.airline_sentiment, pred))
