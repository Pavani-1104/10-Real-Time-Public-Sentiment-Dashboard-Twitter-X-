"""Batch job: roll the live stream up into logs/daily_sentiment.csv (one row per day x brand).
Run it on a schedule (cron / Task Scheduler) or once a day."""
from pathlib import Path
import pandas as pd

SRC, OUT = Path("data/stream/live_tweets.csv"), Path("logs/daily_sentiment.csv")


def main():
    df = pd.read_csv(SRC)
    df["date"] = pd.to_datetime(df["ingested_at"]).dt.date
    g = df.groupby(["date", "airline"])
    log = g.agg(tweets=("tweet_id", "count"),
                positive=("sentiment", lambda s: (s == "positive").sum()),
                neutral=("sentiment", lambda s: (s == "neutral").sum()),
                negative=("sentiment", lambda s: (s == "negative").sum()),
                avg_compound=("vader_compound", "mean")).reset_index()
    log["net_sentiment"] = ((log.positive - log.negative) / log.tweets).round(3)
    log["avg_compound"] = log["avg_compound"].round(3)
    OUT.parent.mkdir(exist_ok=True)
    log.to_csv(OUT, index=False)
    print(log.to_string(index=False))


if __name__ == "__main__":
    main()
