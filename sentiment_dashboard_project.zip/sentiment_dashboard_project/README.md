# Real-Time Public Sentiment Dashboard (Airline Tweets)

Track public opinion about brands as tweets arrive: stream → NLP → live dashboard → daily logs.

## Architecture
```
Tweets.csv (replayed as a live stream)  ──►  stream_simulator.py ─┐
X API + Tweepy (optional, paid tier)    ──►  twitter_stream.py   ─┤
                                                                  ▼
                       NLTK clean (nlp.py) + ML classifier + VADER score
                                                                  ▼
                              data/stream/live_tweets.csv ──► dashboard.py (Streamlit, auto-refresh)
                                                                  ▼
                                      daily_log.py ──► logs/daily_sentiment.csv
```

## Run it
```bash
pip install -r requirements.txt
python src/train_model.py                 # once: trains + saves models/sentiment_model.joblib
python src/stream_simulator.py            # terminal 1: live tweets arrive every 2 s
streamlit run dashboard.py                # terminal 2: live dashboard
python src/daily_log.py                   # anytime / daily: writes logs/daily_sentiment.csv
python src/evaluate_vader.py              # VADER vs human labels
```

## Results
| Method | Accuracy vs human labels |
|---|---|
| NLTK VADER (lexicon, no training) | 54% |
| TF-IDF + Logistic Regression (held-out 20%) | 77% |

VADER over-predicts positive on airline tweets (sarcasm, domain words like "delayed"), so the trained model is the primary label and VADER is kept as a secondary polarity score.

## Design decisions (say these in interviews)
- **Why simulate streaming?** Free X API tier has no streaming. Same schema in `twitter_stream.py`, so swapping is one command.
- **Why keep "not/no/never" as tokens?** Stopword removal would turn "not happy" into "happy".
- **Why VADER on raw text but ML on cleaned text?** VADER uses caps, "!!!" and emoji; TF-IDF benefits from normalised tokens.
- **Why Streamlit instead of Tableau?** Python-native, truly live via `st.fragment(run_every=...)`. Tableau needs batch extract refreshes. (Can still export `logs/daily_sentiment.csv` to Tableau.)
- **Net sentiment** = (positive − negative) / total, a single −1…+1 KPI per brand.

## Known limitations (be upfront)
- Replay data overlaps the model's training tweets, so live accuracy in the demo is optimistic; the honest number is the 77% held-out score.
- Dataset is from Feb 2015; airline-only, English-only, no sarcasm handling.
- Neutral class is the weakest (F1 0.61). Next steps: class weighting tuning, transformer (e.g. DistilBERT / RoBERTa), drift monitoring.

## Likely interview questions
1. Lexicon-based vs ML sentiment: trade-offs? 2. Why TF-IDF + bigrams? 3. Precision vs recall for the negative class here? 4. How do you handle sarcasm/emoji? 5. How would you scale to millions of tweets/day (Kafka, Spark Streaming)? 6. How do you detect model drift? 7. Why is accuracy misleading on imbalanced data (63% negative)? 8. Streaming vs batch refresh?
